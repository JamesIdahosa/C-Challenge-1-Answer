﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class challengeScript : MonoBehaviour{
	
	public Dictionary<string, int> mDictionary = new Dictionary<string, int>();


	//calls lowestOccuranceNumberInFile with inputs 1.txt,2.txt,...5.txt so we get all files
	void Start(){
		for(int i = 1; i <= 5; i++){
			lowestOccuranceNumberInFile(i + ".txt");
		}
    }

    
	//This Method checks if file path exist then reads each line in the file and adds it to the mDictionary
	//only add new numbers(represented by keys) to dictionary and if number already exist then increment the number of its occurances(value of the key)
	//keys are string, occurances are integers in mDictionary
	//line 43 to 57 checks if multiple keys with same lowest occurance have same values, if so then set currentfewest to lowest of the key(we then compare keys)
	void lowestOccuranceNumberInFile(string fileName){

		string mfilePath = Application.dataPath + "/QAEngineerChallenge-master/src/" + fileName;

		if(File.Exists(mfilePath)){
			StreamReader sReader = new StreamReader(mfilePath);

			while(!sReader.EndOfStream){
				string line = sReader.ReadLine();
				if(!mDictionary.ContainsKey(line)){
					mDictionary.Add(line, 0);
				}else{
					mDictionary[line]+=1;
				}
			}

			string currentFewest = "";
			float fewestOccurance = Mathf.Infinity;


			foreach(string key in mDictionary.Keys){
				if(mDictionary[key] < fewestOccurance){
					fewestOccurance = mDictionary[key];
					currentFewest = key;
				}else if(mDictionary[key] == fewestOccurance){
					int a;
					int b;
					int.TryParse(key, out a);
					int.TryParse(currentFewest, out b);
					if(a < b){
						currentFewest = key;
					}
				}
			}

			Debug.Log("File: " + fileName + ", Number " + currentFewest + ", Repeatead: " + mDictionary[currentFewest] + " times");
		}
	}




}
